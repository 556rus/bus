<?php
$data_file = 'data.json';

if ($_POST) {
    if (isset($_POST['clear'])) {
        file_put_contents($data_file, json_encode([]));
    } else {
        $data = [];
        foreach ($_POST['route'] as $index => $route) {
            if (!empty(trim($route))) {
                $data[] = [
                    'route' => $_POST['route'][$index],
                    'arrival' => $_POST['arrival'][$index],
                    'stop' => $_POST['stop'][$index],
                    'number' => $_POST['number'][$index],
                    'department' => $_POST['department'][$index],
                    'comment' => $_POST['comment'][$index]
                ];
            }
        }
        file_put_contents($data_file, json_encode($data));
    }
    header('Location: admin.php');
    exit;
}

$data = json_decode(file_get_contents($data_file), true);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Админ-панель</title>
    <style>
        body { font-family: Arial; font-weight: bold; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { padding: 10px; border: 1px solid #ccc; }
        input { width: 95%; padding: 5px; }
        button { 
            padding: 10px 20px; 
            margin: 5px;
            background: #2c3e50;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Админ-панель расписания</h1>
    <form method="POST">
        <table>
            <thead>
                <tr>
                    <th>Маршрут</th>
                    <th>Время прибытия</th>
                    <th>Время стоянки</th>
                    <th>Гос. номера</th>
                    <th>Подразделение</th>
                    <th>Комментарий</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $index => $row): ?>
                <tr>
                    <td><input type="text" name="route[]" value="<?= htmlspecialchars($row['route']) ?>"></td>
                    <td><input type="text" name="arrival[]" value="<?= htmlspecialchars($row['arrival']) ?>"></td>
                    <td><input type="text" name="stop[]" value="<?= htmlspecialchars($row['stop']) ?>"></td>
                    <td><input type="text" name="number[]" value="<?= htmlspecialchars($row['number']) ?>"></td>
                    <td><input type="text" name="department[]" value="<?= htmlspecialchars($row['department']) ?>"></td>
                    <td><input type="text" name="comment[]" value="<?= htmlspecialchars($row['comment']) ?>"></td>
                </tr>
                <?php endforeach; ?>
                <tr>
                    <td><input type="text" name="route[]" placeholder="Новый маршрут"></td>
                    <td><input type="text" name="arrival[]" placeholder="Время прибытия"></td>
                    <td><input type="text" name="stop[]" placeholder="Время стоянки"></td>
                    <td><input type="text" name="number[]" placeholder="Гос. номер"></td>
                    <td><input type="text" name="department[]" placeholder="Подразделение"></td>
                    <td><input type="text" name="comment[]" placeholder="Комментарий"></td>
                </tr>
            </tbody>
        </table>
        <button type="submit">Сохранить изменения</button>
        <button type="button" onclick="addRow()">Добавить строку</button>
        <button type="submit" name="clear" value="1" onclick="return confirm('Очистить всю таблицу?')">Очистить таблицу</button>
    </form>

    <script>
        function addRow() {
            const tbody = document.querySelector('tbody');
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td><input type="text" name="route[]" placeholder="Новый маршрут"></td>
                <td><input type="text" name="arrival[]" placeholder="Время прибытия"></td>
                <td><input type="text" name="stop[]" placeholder="Время стоянки"></td>
                <td><input type="text" name="number[]" placeholder="Гос. номер"></td>
                <td><input type="text" name="department[]" placeholder="Подразделение"></td>
                <td><input type="text" name="comment[]" placeholder="Комментарий"></td>
            `;
            tbody.appendChild(newRow);
        }
    </script>
</body>
</html>