<?php
$data = json_decode(file_get_contents('data.json'), true);
$today = date('d.m.Y');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Расписание автобусов</title>
    <style>
        body {
            font-family: Arial;
            font-weight: bold;
            margin: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #2c3e50;
        }
        .row-white {
            background-color: white;
            color: #2c3e50;
        }
        .row-blue {
            background-color: #2c3e50;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="company-name">Транспортная компания</div>
        <div class="date"><?= $today ?></div>
    </div>
    
    <table>
        <thead>
            <tr class="row-white">
                <th>Маршрут</th>
                <th>Время прибытия</th>
                <th>Время стоянки</th>
                <th>Гос. номера автобусов</th>
                <th>Подразделение</th>
                <th>Комментарий</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $index => $row): ?>
            <tr class="<?= $index % 2 == 0 ? 'row-white' : 'row-blue' ?>">
                <td><?= htmlspecialchars($row['route']) ?></td>
                <td><?= htmlspecialchars($row['arrival']) ?></td>
                <td><?= htmlspecialchars($row['stop']) ?></td>
                <td><?= htmlspecialchars($row['number']) ?></td>
                <td><?= htmlspecialchars($row['department']) ?></td>
                <td><?= htmlspecialchars($row['comment']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>